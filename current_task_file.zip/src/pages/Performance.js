import React from 'react';

const Performance = () => {
  return (
    <div>
        <h1>Performance</h1>
    </div>
  );
}

export default Performance